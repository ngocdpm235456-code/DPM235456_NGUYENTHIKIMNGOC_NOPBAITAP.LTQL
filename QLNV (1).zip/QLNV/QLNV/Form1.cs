﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient; // Thư viện SQL
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLNV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataSet ds = new DataSet("dsQLNV");
        SqlDataAdapter daChucVu;
        SqlDataAdapter daNhanVien;
        string maNV = ""; 

        // Chuỗi kết nối dùng chung
        string strConn = @"Data Source=.\SQLEXPRESS;Initial Catalog=QLNV;Integrated Security=True";

        private void Form1_Load(object sender, EventArgs e)
        {
            ds.Clear();

            SqlConnection conn = new SqlConnection(strConn);

            string sQueryChucVu = @"select * from chucvu";
            daChucVu = new SqlDataAdapter(sQueryChucVu, conn);
            daChucVu.Fill(ds, "tblChucVu");
            cboChucVu.DataSource = ds.Tables["tblChucVu"];
            cboChucVu.DisplayMember = "tencv";
            cboChucVu.ValueMember = "macv";

            string sQueryNhanVien = @"select n.*, c.tencv from nhanvien n, chucvu c 
                                      where n.macv=c.macv";
            daNhanVien = new SqlDataAdapter(sQueryNhanVien, conn);
            daNhanVien.Fill(ds, "tblDSNhanVien");

            dataGridView.DataSource = ds.Tables["tblDSNhanVien"];

            dataGridView.Columns["manv"].HeaderText = "Mã số";
            dataGridView.Columns["manv"].Width = 80;
            dataGridView.Columns["holot"].HeaderText = "Họ lót";
            dataGridView.Columns["tennv"].HeaderText = "Tên";
            dataGridView.Columns["ngaysinh"].HeaderText = "Ngày sinh";
            dataGridView.Columns["phai"].HeaderText = "Phái";

            if (dataGridView.Columns.Contains("macv"))
                dataGridView.Columns["macv"].Visible = false;
        }

        private void dataGridView_Click(object sender, EventArgs e)
        {


            if (dataGridView.CurrentRow == null) return;

            DataGridViewRow dr = dataGridView.CurrentRow;
            txtMaNV.Text = dr.Cells["manv"].Value.ToString();
            txtHoLot.Text = dr.Cells["holot"].Value.ToString();
            txtTen.Text = dr.Cells["tennv"].Value.ToString();

            string phai = dr.Cells["phai"].Value.ToString();
            if (phai == "Nam") 
                radNam.Checked = true;
            else 
                radNu.Checked = true;

            dtpNgaySinh.Value = Convert.ToDateTime(dr.Cells["ngaysinh"].Value);
            cboChucVu.SelectedValue = dr.Cells["macv"].Value.ToString();

            txtMaNV.Enabled = false;
            btnSua_Click(sender, e);
            cboChucVu.Enabled = false;
            txtMaNV.Enabled = false;
            txtHoLot.Enabled = false;
            txtTen.Enabled = false;
            dtpNgaySinh.Enabled = false;
            radNam.Enabled = false;
            radNu.Enabled = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Đánh dấu là đang Thêm mới
            maNV = "";

            cboChucVu.Enabled = true;
            txtMaNV.Enabled = true;
            txtHoLot.Enabled = true;
            txtTen.Enabled = true;
            dtpNgaySinh.Enabled = true;
            radNam.Enabled = true;
            radNu.Enabled = true;

            txtMaNV.Enabled = true; 
            txtMaNV.Text = "";
            txtHoLot.Text = "";
            txtTen.Text = "";
            cboChucVu.SelectedIndex = -1;
            radNam.Checked = false;
            radNu.Checked = false;
            dtpNgaySinh.Value = DateTime.Now;
            txtMaNV.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            maNV = txtMaNV.Text;
            txtMaNV.Enabled = false;
            cboChucVu.Enabled = true;
            txtMaNV.Enabled = true;
            txtHoLot.Enabled = true;
            txtTen.Enabled = true;
            dtpNgaySinh.Enabled = true;
            radNam.Enabled = true;
            radNu.Enabled = true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra dữ liệu
            if (cboChucVu.Text.Trim() == "") 
            { 
                MessageBox.Show("Chưa chọn chức vụ!"); 
                return; 
            }
            if (txtMaNV.Text.Trim() == "") 
            {
                MessageBox.Show("Mã NV trống!"); 
                return; 
            }
            if (txtTen.Text.Trim() == "")
            { MessageBox.Show("Tên trống!"); 
                return; 
            }
            if (!radNam.Checked && !radNu.Checked)
            { MessageBox.Show("Chưa chọn giới tính!");
                return;
            }
            SqlConnection conn = new SqlConnection(strConn);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                string sPhai = radNu.Checked ? "Nữ" : "Nam";

                if (maNV == "") // THÊM MỚI
                {
                    SqlCommand cmdCheck = new SqlCommand("SELECT COUNT(*) FROM nhanvien WHERE manv=@MaNV", conn);
                    cmdCheck.Parameters.Add("@MaNV", SqlDbType.NVarChar, 5).Value = txtMaNV.Text;
                    int count = (int)cmdCheck.ExecuteScalar();
                    if (count > 0) 
                    {
                        MessageBox.Show("Mã nhân viên đã tồn tại!");
                        return; 
                    }

                    string sThemNV = @"INSERT INTO nhanvien(manv, holot, tennv, phai, ngaysinh, macv) 
                                       VALUES(@MaNV, @HoLot, @TenNV, @Phai, @NgaySinh, @MaCV)";
                    cmd.CommandText = sThemNV;
                }
                else // SỬA 
                {
                    string sSuaNV = @"UPDATE nhanvien 
                                      SET holot=@HoLot, tennv=@TenNV, phai=@Phai, ngaysinh=@NgaySinh, macv=@MaCV 
                                      WHERE manv=@MaNV";
                    cmd.CommandText = sSuaNV;
                }
                cmd.Parameters.Add("@MaNV", SqlDbType.NVarChar, 5).Value = txtMaNV.Text;
                cmd.Parameters.Add("@HoLot", SqlDbType.NVarChar, 50).Value = txtHoLot.Text;
                cmd.Parameters.Add("@TenNV", SqlDbType.NVarChar, 10).Value = txtTen.Text;
                cmd.Parameters.Add("@Phai", SqlDbType.NVarChar, 3).Value = sPhai;
                cmd.Parameters.Add("@NgaySinh", SqlDbType.SmallDateTime).Value = dtpNgaySinh.Value;
                cmd.Parameters.Add("@MaCV", SqlDbType.NVarChar, 5).Value = cboChucVu.SelectedValue;

                cmd.ExecuteNonQuery();
                MessageBox.Show("Lưu thành công!", "Thông báo");

                Form1_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (txtMaNV.Text == "")
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần xóa!");
                return;
            }

            DialogResult kq;
            kq = MessageBox.Show("Bạn có chắc chắn muốn xóa nhân viên " + txtTen.Text + " và toàn bộ dữ liệu lương liên quan không?", "Xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (kq == DialogResult.Yes)
            {
                SqlConnection conn = new SqlConnection(strConn);
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    string sqlXoaLuong = @"DELETE FROM quatrinhluong WHERE manv = @MaNV";
                    cmd.CommandText = sqlXoaLuong;
                    cmd.Parameters.Add("@MaNV", SqlDbType.NVarChar, 5).Value = txtMaNV.Text;
                    cmd.ExecuteNonQuery();

                    string sqlXoaNV = @"DELETE FROM nhanvien WHERE manv = @MaNV";
                    cmd.CommandText = sqlXoaNV;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@MaNV", SqlDbType.NVarChar, 5).Value = txtMaNV.Text;

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Đã xóa thành công!");

                    Form1_Load(sender, e);
                    btnThem_Click(sender, e);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi xóa: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void btnHuyBo_Click(object sender, EventArgs e)
        {
            // Reset lại trạng thái ban đầu
            btnThem_Click(sender, e);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}